"use strict";

function MakeEntry({name = "???", pic = null, bounty = null} = {}) {
    var entryObj = document.createElement("div");
    entryObj.classList.add("entry");


    entryObj.name = name;
    entryObj.pic = pic;
    entryObj.bounty = bounty;

   var display = function() {
        entryInfo.innerHTML = `
            <h3>${entryObj.name}</h3>
            <img class="codeImg" src="${entryObj.pic}" />
            <p>Bounty: ${entryObj.bounty}</p>
    `; }

    var bountyEdit = function(offer) {
        var b = Number(offer);
        if (isNaN(b)) {
            console.log("ERROR: Not a number. Please enter a number.");
            return null;
        }
        entryObj.bounty = entryObj.bounty + b;
        display();

    }
    entryObj.innerHTML = `
    <div class= "entryInfo"></div>
    <p>Instructions: Use the textbox below to set the wyvern's name. It will update in real-time!</p> </br>
    <input class= 'nameInput'/> </br>
    <p>Instructions: Use the controls below to shift the bounty of the monster. Use a negative number to lower the bounty. Using a non-number will cause an error.</p> </br>
    <button class= 'bountyButton'> Update Bounty By:</button> 
    <input class= 'bountyInput' /> </br>
    <p> Instructions: Use the textbox below to provide a new image URL for the wyvern (Please Only USE PNGs or JPEGs). </p> </br>
    <input class= 'imgInput'/>
    `;
    
    var entryInfo = entryObj.getElementsByClassName("entryInfo")[0];
    var nameInput = entryObj.getElementsByClassName("nameInput")[0];
    var bountyInput = entryObj.getElementsByClassName("bountyInput")[0];
    var bountyButton = entryObj.getElementsByClassName("bountyButton")[0];
    var wyvernImg = entryObj.getElementsByClassName("imgInput")[0];

    nameInput.oninput = function() { //Non-buttonclick function 
        entryObj.name = nameInput.value;
        display();
    }
    bountyButton.onclick = function() {
        bountyEdit(bountyInput.value);
    }
    wyvernImg.oninput = function() { // Non-buttonclick function
        entryObj.pic = wyvernImg.value;
        display();
    }
    

    display();
    return entryObj;
}