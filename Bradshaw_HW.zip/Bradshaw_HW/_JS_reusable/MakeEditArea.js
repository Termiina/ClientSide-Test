"use strict";
/* 
 * MakeEditArea expects a parameter object with the following inputs: 
 *     inputSpecs: array of objects (one object per field the user is supposed to type in)
 *     successCallBack:  consumer function to be called if the user clicks submit and all 
 *         inputs pass validation (Provider code will pass an object full of user inputs -- 
 *         to the consumer successCallBack function). 
 *     cancelCallBack: consumer function to be called if the user clicks cancel. 
 *     editObj: if provided, the field values in this object will be prefilled in the user input boxes. 
 *         (field names of editObj must match the field names specified in the inputSpecs).
 * 
 * MakeEditArea returns a div that contains a prompt, an input box, and a  possible error 
 * message for each input the user is supposed to enter.   It also has a submit button, a 
 * cancel button, and a "record level" message (e.g., "all good" or "please try again").
 * 
 * Here are the properties currently expected in inputSpec objects (however, you'll add/subtract
 * properties for your HW):
 *    "prompt": "User Email: ",   --> prompt for the input tag
 *    "fieldName": "userEmail",   --> fieldName to use when storing user's input 
 *    "dataType": "string",       --> type of data - you add your own types like date, or integer
 *    "isRequired": true,         --> NOTE: this is a boolean, no quotes.
 *    "maxLen": 50                --> maxLen, max # characters to be checked, if provided 
 */

function MakeEditArea({ inputSpecs, successCallBack, cancelCallBack, editObj = {} }) {
    var errorMsg = "";

    if (!inputSpecs || !inputSpecs[0]) {
        errorMsg += "MakeEditArea did not receive a parameter property named 'inputSpecs'\n" +
            "that has at least one object (that defines one input field). <br/><br/>";
    }

    if (!successCallBack || !(successCallBack instanceof Function)) {
        errorMsg += "MakeEditArea did not receive a parameter property named 'successCallBack',\n" +
            "a Consumer function that will be called (passing an object full of user entered data)\n" +
            "if the user clicks 'Submit' and all the inputs validate. <br/><br/>";
    }

    if (!cancelCallBack || !(cancelCallBack instanceof Function)) {
        var errorMsg = "MakeEditArea did not receive a parameter property named 'cancelCallBack',\n" +
            "a Consumer function that will be called if the user clicks 'Cancel'.\n" +
            "(no input will be passed to the cancel call back function). <br/><br/>";
    }

    if (errorMsg.length > 0) {
        alert(errorMsg); // this would generally be a programmer error, not user error
        throw errorMsg; // this would generally stop execution

        // but if you do not want to throw the message, then return an error message div like this: 
        var errorDiv = document.createElement("div");
        errorDiv.innerHTML = errorMsg;
        return errorDiv; // early return, avoids errors we'd get due to insufficient input parameters. 
    }


    var editDiv = document.createElement("div");
    editDiv.classList.add("editArea");

    editDiv.innerHTML = `
    <div class="coreDiv"></div>
    <button class="saveButtonC">Save</button>
    <button class="cancelButtonC">Cancel</button>
    <span class="recLevelMsgC"></span>
    `;

    var core = editDiv.getElementsByClassName("coreDiv")[0];
    var saveButton = editDiv.getElementsByClassName("saveButtonC")[0];
    var cancelButton = editDiv.getElementsByClassName("cancelButtonC")[0];
    var recLevelMsg = editDiv.getElementsByClassName("recLevelMsgC")[0];


    // create one row per input field. Each row shall contain prompt, input box, and container for 
    // error msg. 

    for (var spec of inputSpecs) {

        var theCore = MakeTag({
            htmlTag: "div",
            parent: core,
            cssClass: "core"
        });

        // Add prompt for field...
        MakeTag({
            htmlTag: "span",
            cssClass: "prompt",
            innerHTML: spec.prompt,
            parent: theCore
        });

        // use this as the "type" attribute of the input tag
        var textOrDate = "text";
        if (spec.dataType === "date") {
            textOrDate = "date";

            // format must be YYYY-MM-DD to correctly pre-fill the input date tag.
            console.log("Date value is " + editObj[spec.fieldName]);
        } else if (spec.dataType === "number" || spec.dataType === "integer") {
            textOrDate = "number";
        }

        // Add input tag for field. We need to access later, so save it right into the inputSpecs 
        // object that it relates to.
        // Decide which control to create
        if (spec.controlType === "select") {

            // Create select list
            spec.selectTag = MakeTag({
                htmlTag: "select",
                parent: theCore
            });

            for (var choice of spec.choices) {
                var option = MakeTag({
                    htmlTag: "option",
                    value: choice,
                    innerHTML: choice,
                    parent: spec.selectTag
                });

                if (choice === editObj[spec.fieldName]) {
                    option.selected = true;
                }
            }

        } else if (spec.controlType === "radio") {

            // Create radio buttons
            spec.radioTag = MakeRadio({
                prompt: "",
                choices: spec.choices,
                selected: editObj[spec.fieldName] || ""
            });

            theCore.appendChild(spec.radioTag);

        } else {

            // Create regular textbox or date input
            spec.inputTag = MakeTag({
                htmlTag: "input",
                type: textOrDate,
                value: editObj[spec.fieldName] || "",
                parent: theCore
            });

        }

        MakeTag({ // put a space after the textbox, before the error message
            htmlTag: "span",
            innerHTML: "&nbsp;",
            parent: theCore
        });
        // Add span tag to hold error Msg for this field. We need to access this later, so save it
        // right into the inputSpecs object that it relates to.
        spec.errorMsg = MakeTag({
            htmlTag: "span",
            cssClass: "error",
            parent: theCore
        });
    } //  for (var spec of inputSpecs)


    /* 
    Validate.js holds a global object named Validate that has the following 
    methods. All methods return a validation error message or an empty string 
    if validation passed.  
        Validate.Number = function (inputVal, isRequired) {...}
        Validate.Integer = function (inputVal, isRequired) {...}
        Validate.String = function (inputVal, isRequired, maxLen) {...}
        Validate.RequiredField = function (inputVal, isRequired) {...}
    */

    saveButton.onclick = function () {
        /* Here, you must add code to validate each input tag (check that it matches the specs 
        provided, e.g., correct data type). 
        
        The code currently only checks that each input 
        is as long as the minimum length requirement.) For every bad input, put an error 
        message (in that row). If any row has bad input, set the record level message like 
        "Please try again".
        */
        var allErrors = "";

    for (var spec of inputSpecs) {
        var inputVal = "";

        // Get the value from the correct control.
        if (spec.inputTag) {
            inputVal = spec.inputTag.value;
        } else if (spec.selectTag) {
            inputVal = spec.selectTag.value;
        } else if (spec.radioTag) {
            var selectedRadio = spec.radioTag.querySelector(
                'input[type="radio"]:checked'
            );

            inputVal = selectedRadio ? selectedRadio.value : "";
        }

        // Validate the value.
        if (spec.controlType === "select" || spec.controlType === "radio") {
            spec.errorMsg.innerHTML =
                Validate.RequiredField(inputVal, spec.isRequired);

        } else if (spec.dataType === "string") {
            spec.errorMsg.innerHTML =
                Validate.String(inputVal, spec.isRequired, spec.minLen, spec.maxLen);
                console.log(spec.fieldName + ": " + spec.errorMsg.innerHTML);
        } else if (spec.dataType === "integer") {
            spec.errorMsg.innerHTML =
                Validate.Integer(inputVal, spec.isRequired, spec.minValue, spec.maxValue);
                console.log(spec.fieldName + ": " + spec.errorMsg.innerHTML);
        } else if (spec.dataType === "number") {
            spec.errorMsg.innerHTML =
                Validate.Number(inputVal, spec.isRequired, spec.minValue, spec.maxValue);
                console.log(spec.fieldName + ": " + spec.errorMsg.innerHTML);
        } else if (spec.dataType === "date") {
            spec.errorMsg.innerHTML =
                Validate.RequiredField(inputVal, spec.isRequired);

        } else {
            spec.errorMsg.innerHTML = "No such data exists...";
        }

        allErrors += spec.errorMsg.innerHTML;
    }

    // Stop if any field has an error.
    if (allErrors.length > 0) {
        recLevelMsg.innerHTML = "Something is amiss...";
        return;
    }

    recLevelMsg.innerHTML = "Ayyy!";

    // Save the values into editObj.
    for (var spec of inputSpecs) {
        if (spec.inputTag) {
            editObj[spec.fieldName] = spec.inputTag.value;
        } else if (spec.selectTag) {
            editObj[spec.fieldName] = spec.selectTag.value;
        } else if (spec.radioTag) {
            var selectedRadio = spec.radioTag.querySelector(
                'input[type="radio"]:checked'
            );

            editObj[spec.fieldName] = selectedRadio ? selectedRadio.value : "";
        }
    }

    // Send the completed object to the success callback.
    successCallBack(editObj);
    };

    function clearAll() {
        // Blank out all input tags and also the record level message.
        for (var spec of inputSpecs) {
        if (spec.inputTag) {
            spec.inputTag.value = "";
        }

        if (spec.selectTag) {
            spec.selectTag.selectedIndex = 0;
        }

        if (spec.radioTag) {
            var selectedRadio = spec.radioTag.querySelector(
                'input[type="radio"]:checked'
            );

            if (selectedRadio) {
                selectedRadio.checked = false;
            }
        }

        spec.errorMsg.innerHTML = "";
    }

    recLevelMsg.innerHTML = "";
    }

    cancelButton.onclick = function () {
        // Since the user is cancelling, clear out all inputs and record level msg. 
        clearAll();
        cancelCallBack();
    };

    console.log("Save buttons:", editDiv.getElementsByClassName("saveButtonC").length);
    console.log("Cancel buttons:", editDiv.getElementsByClassName("cancelButtonC").length);


    return editDiv;
}