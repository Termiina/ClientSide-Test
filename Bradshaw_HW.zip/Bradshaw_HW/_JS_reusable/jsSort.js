// This function sorts the array of objects in "list" by object property "byProperty", 
// assuming that the sort property is of the given type (e.g., text, number, or date).
// There is no return parameter - objList is sorted in place (I/O) parameter.

function jsSort(objList, byProperty, sortType) {

    if (!objList || !objList[0]) {
        var message = "Cannot sort. Need an ObjList that has at least one element";
        console.log(message);
        alert(message);
        return;  // early return -- dont try to sort.
    }

    console.log('to jsSort byProperty ' + byProperty + ' sort type ' + sortType);

    var obj = objList[0];
    if (!(byProperty in obj)) {
        var message = `Cannot sort because objList does not have property ${byProperty}.`;
        console.log(message);
        alert(message);
        return;  // early return -- dont try to sort.
    }

    /* 
    To use the JS sort method (that's available on ANY JS array), you pass it 
    function that compares two elements from the array. This function returns 
    a positive # if the first element is bigger, returns a negative # if the 
    second element is bigger, or returns a 0 if the elements are the same. 
 
    In the example below, q and z (input to the anonymous comparitor function)
    represent two arbitrary elements from the array.  

    We use JS associative array notation to access the property by which the 
    consumer wishes to sort. Using associative array notation, obj.propName 
    can be written obj["propName"] (allows the consumer to pass in the property 
    name as a string). 
    */ 
    objList.sort(function (q, z) {  // in line (and anonymous) def'n of fn to compare list elements. 
        // the function you create is supposed to return positive (if first bigger), 0 if equal, negative otherwise.

        // using JS associative array notation, extract the 'byProperty' property from the two
        // list elements so you can compare them.
        var qVal = sortOrder(q[byProperty], sortType);
        var zVal = sortOrder(z[byProperty], sortType);

        var c = 0;
        if (qVal > zVal) {
            c = 1;
        } else if (qVal < zVal) {
            c = -1;
        }
        //console.log("comparing " + qVal + " to " + zVal + " is " + c);
        return c;
    });

} // jsSort