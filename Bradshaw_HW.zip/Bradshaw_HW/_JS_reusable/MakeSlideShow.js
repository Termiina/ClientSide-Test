"use strict";

function MakeSlideShow({
    title = "Untitled",
    slides = [{ imgName: null, caption: "Placeholder", bonusInfo: "Something" }],
    imageFilter = "none",
    storageKey = "default"
} = {}) {
    var slideshow = document.createElement("div");
    slideshow.classList.add("slideshow");

    var savedSlide = Number(localStorage.getItem(storageKey));
    var picNum = 0;

    if (localStorage.getItem(storageKey) !== null &&
        Number.isInteger(savedSlide) &&
        savedSlide >= 0 &&
        savedSlide < slides.length) {
        picNum = savedSlide;
    }

    slideshow.innerHTML = `
        <h1> ${title} </h1>
        <div>
            <img class="slideShowtime"/>
        </div>
        <p class="slideCaption"></p>
        <p>
            <button class="unveilButton">Click for more!</button>
        </p>
        <div class="bonusInfoH hide">
            <p> ${slides[picNum].bonusInfo} </p>
            <button class="veilButton">Veil the info.</button>
        </div>

        <div>
            <button class="prevButton"> Back </button> &nbsp;
            <button class="nextButton"> Next </button>
        </div>
    `;

    var display = function () {
        console.log(slides[picNum].caption, slides[picNum].imgName);
        slideImage.src = slides[picNum].imgName;
        slideCaption.innerHTML = slides[picNum].caption;
        bonusInfo.querySelector("p").innerHTML = slides[picNum].bonusInfo;
    }

    var slideImage = slideshow.getElementsByClassName("slideShowtime")[0];
    slideImage.style.filter = imageFilter;
    var unveilButton = slideshow.getElementsByClassName("unveilButton")[0];
    var veilButton = slideshow.getElementsByClassName("veilButton")[0];
    var prevButton = slideshow.getElementsByClassName("prevButton")[0];
    var nextButton = slideshow.getElementsByClassName("nextButton")[0];
    var slideCaption = slideshow.getElementsByClassName("slideCaption")[0];
    var bonusInfo = slideshow.getElementsByClassName("bonusInfoH")[0];


    unveilButton.onclick = function () {
        bonusInfo.classList.add("show");
        bonusInfo.classList.remove("hide");
        unveilButton.classList.add("hide");
        unveilButton.classList.remove("show");

    }
    veilButton.onclick = function () {
        bonusInfo.classList.add("hide");
        bonusInfo.classList.remove("show");
        unveilButton.classList.add("show");
        unveilButton.classList.remove("hide");
    }

    function persistCurrentSlide() {
        localStorage.setItem(storageKey, picNum);
    }

    prevButton.onclick = function () {
        picNum--;
        if (picNum < 0) {
            picNum = slides.length - 1;
        }
        persistCurrentSlide();
        display();
    };

    nextButton.onclick = function () {
        picNum++;
        if (picNum >= slides.length) {
            picNum = 0;
        }
        persistCurrentSlide();
        display();
    };

    display();
    return slideshow;
}