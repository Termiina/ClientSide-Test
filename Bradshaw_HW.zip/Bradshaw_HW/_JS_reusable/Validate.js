"use strict";

// We are still following JS file naming convention: 
// "JS file name matches the single JS function or object defined within."
// Validate object matches Validate.js 
var Validate = {};

// Now we add public methods to Validate object (all validation functions)

Validate.Number = function (inputVal, isRequired, min, max) {
    if (isRequired && inputVal.length === 0) {
        return "Required";
    }
    if (isNaN(inputVal)) {
        return "Error. Not a valid number.";
    }
    var number = Number(inputVal);

    if (number < min) {
        return "Error. Number must be at least " + min + ".";
    }

    if (number > max) {
        return "Error. Number must be no greater than " + max + ".";
    }

    return ""; // no error message means input passed validation.
}

// Using Fat Arrow notation 
// (just an alternative to "regular" function definition above)
Validate.Integer = (inputVal, isRequired, minValue, maxValue) => {
    if (isRequired && inputVal.length === 0) {
        return "Required";
    }
    if (isNaN(inputVal)) {
        return "Error. Not a valid integer.";
    }

    var numVal = Number(inputVal);

    if (!Number.isInteger(numVal)) {
        return "Error. You entered a number, but it's not an integer.";
    }

    if (numVal < minValue) {
        return "Error. Number must be at least " + minValue + ".";
    }

    if (numVal > maxValue) {
        return "Error. Number must be no greater than " + maxValue + ".";
    }

    return "";
}

Validate.String = (inputVal, isRequired, minLen, maxLen) => {
    // currently not checking maxLen
    if (isRequired && inputVal.length === 0) {
        return "Required";
    }
     if (!isRequired && inputVal.length === 0) {
        return "";
    }

    var length = inputVal.length;
    var minimum = Number(minLen);
    var maximum = Number(maxLen);

    if (length < minimum) {
        return "Please enter at least " + minimum + " characters.";
    }

    if (length > maximum) {
        return "Please enter no more than " + maximum + " characters.";
    }

    return ""; // No error means validation passed

    // when you check for maxLen, give a GOOD error message that 
    // lets the user know how long their input can be.... 
    // return "Error: Please shorten your input to " + inputVal.substring(0, maxLen);

    return ""; // no error message means input passed validation.
}

/* Note about date validation... I wanted to write some JS code (like above)
to check if a user entered string was a valid date but it actually seems difficult 
(and looks like you need a framework !!!)  So, we will just use the HTML5 
input type="date" which provides a nice date UI and no way the user can enter 
an invalid date. All we need to do is check that the user clicked a date 
(if the date input is required). For this, we can use the generic "RequiredField"
validation below, for a date or any type of input). 
*/
Validate.RequiredField = (inputVal, isRequired) => {
    if (isRequired && inputVal.length === 0) {
        return "Required";
    }
    if (inputVal.value === "<input type= date") {
        return "Error. Please select a date.";
    }
    return ""; // no error message means input passed validation.
}