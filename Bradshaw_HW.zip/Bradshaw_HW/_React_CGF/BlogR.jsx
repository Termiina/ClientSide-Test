"use strict"; 

function BlogR() {
    return (
        <div className="blog">
            <h1>My Web Development Experience</h1>
            <p>
                I haven't really done much web development before, as the most I have done has been for classes like
                Pascucci's class and this one so I am very novice.
            </p>
            <p>
                What I found easy was writing down the content areas, as it seems pretty straight forward.
                I also found it easy to get the footer to work and understand the nav code. Implementing it , as well as
                the dimensions and spacing was hard.
                It still confuses me a bit, so I'll need some time to fully get it down as I can be show at first with
                learning new coding languages.
            </p>
            <p>
                I do think that all of this information is valuable to know, so I'm mostly grateful to learn it.
            </p>
            <h2> JSON File </h2>
            Click <a href="json/monsters.json" target="_blank">View Wyverns</a> to see more about the monsters mentioned here!
            <h2> React/JS Thoughts</h2>
            <p>Understanding what the code does was slightly daunting but I could follow it mostly. What
                came difficult was understanding what I wanted to put into the page. I have an issue of overcomplicating
                what I am asked to do and that came into play here, so things took longer than needed.
            </p>
            <h2> JS Objects </h2>
            <p> 
                What came easy with this homework was creating the objects. Doing the lab helped with cementing the basics of creating these objects. Using
                a different function aside from onclick was challenging, cause it was becoming very fickle to opperate. At a point, the page wouldn't load. I think
                learning this is valuable so you cam make more interactive websites for consumers.
            </p>
            <h2> Slideshow x AJAX </h2>
            <p>
                The slide show implementation was easy, however once I had to start calling AJAX it got very tedious on my end. I kept second guessing myself on how to make the attributes of the
                objects map correctly. It was also confusing to get the visual effect on the slideshow to work. Overall, I think knowing Ajax is valuable to know so fetching information becomes easier.
                As for the <a href="json/monsters.json" target="_blank">Wyvern Info</a> and <a href="json/endemic.json" target="_blank">Endemic Info</a>, here you go!
            </p>
            <h2> Object Lists </h2>
            <p>
                The object lists were easy at a base level, as it is just a bunch of objects slammed into an array. What came difficult and tedious was the info not loading and the buttons not working 
                initially. Even after submission, I couldnt get the images to load or some of the mins and maxes to work. I'll have to go back later and fix it but this is a fruitful aspect of html for grouping info
                together.

            </p>
            <h2> Edit Area </h2>
            <p>For me, the only easy part was constructing the edit areas' CGFs. It's basically just a bunch of specificying and hardcoding.
                Everthing else was tedious. At some point, it wasnlt aligned and there were others issues with getting the select list to be recognized
                I believe this is a valuable skill to have for making websites more interacitve and alive, though. All in all, I need practice with implementing these.</p>
        </div>
    );
}