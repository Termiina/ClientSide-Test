"use strict"; 

function HomeR() {
    return (
        <div className="home">
            <h1>
                Welcome to Monster Hunting!
            </h1>

            <p>This is the home page of the Monster Hunting website.
                Here you can find information about monsters people have hunted in recent expeditions in various Monster
                Hunter Games, along with their experiences.</p>
            <p>This website will show users pictures of some of the most interesting beasts and wyverns I have run into,
                along with their locations, weaknesses, and characteristics. I'll even share my thoughts on each monster
                presented.
            </p>
            <p>
                Click <a href="https://www.monsterhunter.com/" target="_blank">here</a> to go to the 
                see the official Monster Hunter website for more information on the game series.
            </p>
            <a href="json/monsters.json" target="_blank">View Wyverns</a>
        </div>
    );
}