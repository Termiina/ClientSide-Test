"use strict";
// the function name
function UsersComingSoonR() {
    // What gets injected
    return (
        <div className="users-coming-soon">
            <h1>New Data is in the works!</h1>
            <p>I am working now to get more info on my Monster Hunting journey up as soon as I can!</p>
            <p>For now, here is an icon of a personal favorite monster from the game</p>
            <img class="codeImg" src="style/Zino.jpg" />
        </div>

    );
}