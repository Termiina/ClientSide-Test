"use strict";

function MakeEditAreaWyvern_CGF(){
    
    var ele = document.createElement("div");

    ele.innerHTML = `
        <h1>Edit Wyvern Info</h1>
        Use the controls below to log the info of hunts you've been on. The type of wyvern,
        the date of the hunt, the bounty you collected, and more!
        
        <div class="editAreaC"></div>
        <div class="msgArea"></div>
        `;
    
    var wyvernArea = ele.getElementsByClassName("editAreaC")[0];
    var msgArea = ele.getElementsByClassName("msgArea")[0];
    
    var inputSpecs = [
        {
            "prompt": "What was the wyvern's name? Name no shorter than 3 characters, no longer than 30 characters. ",
            "fieldName": "beastName",
            "dataType": "string",
            "isRequired": true, 
            "minLen": 3,
            "maxLen": 30
        },
        {
            "prompt": "When did you hunt them? (Required) ",
            "fieldName": "huntDate",
            "dataType": "date",
            "isRequired": true, 
        },
        {
            "prompt": "What was the bounty? No less than 0, no more than 300,000. ",
            "fieldName": "bounty",
            "dataType": "integer",
            "minValue": 0,
            "maxValue": 300000
        },
        {
            "prompt": "What type of wyvern was it? ",
            "fieldName": "beastType",
            "controlType": "select",
            "choices": ["Fanged Wyvern", "Flying Wyvern", "Brute Wyvern", "Elder Dragon"]
        },
        {
            "prompt": "What was the hunt's difficulty? ",
            "fieldName": "huntDifficulty",
            "controlType": "radio",
            "choices": ["A cakewalk", "Average", "I was struggling alot...", "Thrashed like a ragdoll"],
        }

    ];
    var presetInfo = {
        "beastName": "Rathalos",
        "huntDate": "2024-06-01",
        "bounty": 5000,
        "beastType": "Flying Wyvern",
        "huntDifficulty": "Average"
    };

    function success(editObj) {
        msgArea.innerHTML = `
            <p>Here's what you logged:</p>
            <ul>
                <li>Wyvern Name: ${editObj.beastName}</li>
                <li>Hunt Date: ${editObj.huntDate}</li>
                <li>Bounty: ${editObj.bounty}</li>
                <li>Wyvern Type: ${editObj.beastType}</li>
                <li>Hunt Difficulty: ${editObj.huntDifficulty}</li>
            </ul>
        `;
    }

    function cancel() {
        msgArea.innerHTML = `
            <h3>Your info's been reset. Select everything again.</h3>
        `;
    }

    var editArea = MakeEditArea({
        inputSpecs: inputSpecs,
        successCallBack: success,
        cancelCallBack: cancel,
        editObj: presetInfo
    });
    wyvernArea.appendChild(editArea);

    return ele;
}