"use strict";
 function EntryList_CGF(){
    var ele = document.createElement("div");

    ajax("json/monsters.json", WyvernMethod, ele);
    function WyvernMethod(WyvernList){
        var WyvernEntries = 
        MakeEntryList({entryList: WyvernList, title: "Wyvern List", entryDesc: "These monsters are attacking! Take a look!"});
        ele.appendChild(WyvernEntries);
    }

    ajax("json/endemic.json", endemicMethod, ele);
    function endemicMethod(EndemicList){
        var theEndemics =
        MakeEntryList({entryList: EndemicList, title: "Endemic List", entryDesc: "Awww! The little lifeforms around the area!"});
        ele.appendChild(theEndemics);
    }
    
    var fauxEntry = MakeEntryList({});
    ele.appendChild(fauxEntry);

    return ele;
 }
