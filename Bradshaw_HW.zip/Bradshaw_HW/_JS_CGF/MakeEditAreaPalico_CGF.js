"use strict";

function MakeEditAreaPalico_CGF(){
    
    var ele = document.createElement("div");

    ele.innerHTML = `
        <h1>Edit Palico Info</h1>
        Use the controls below to describe your palico. The type of palico,
        when you first met them, and anything else you want to share.
        
        <div class="editAreaC"></div>
        <div class="msgArea"></div>
        `;
    
    var palicoArea = ele.getElementsByClassName("editAreaC")[0];
    var msgArea = ele.getElementsByClassName("msgArea")[0];
    
    var inputSpecs = [
        {
            "prompt": "What's your little buddy's name? No shorter than 2 characters, no longer than 15 characters. ",
            "fieldName": "palicoName",
            "dataType": "string",
            "isRequired": true, 
            "minLen": 2,
            "maxLen": 15
        },
        {
            "prompt": "When did you first meet them? (Optional) ",
            "fieldName": "meetDate",
            "dataType": "date",
            "isRequired": false, 
        },
        {
            "prompt": "How many hunts have you been on with them? No less than 1, no more than 50,000. ",
            "fieldName": "hunts",
            "dataType": "number",
            "minValue": 1,
            "maxValue": 50000
        },
        {
            "prompt": "What's your strategy when hunting with your palico? ",
            "fieldName": "strategy",
            "controlType": "select",
            "choices": ["Have it deal as much damage as possible", "Maximize its ability to inflict ailments", "Have it support me and others with traps and healing", "I don't hunt with them "]
        },
        {
            "prompt": "Do you prefer to hunt with them or without them? ",
            "fieldName": "preference",
            "controlType": "radio",
            "choices": ["Yes", "No"],
        }

    ];

    function success(editObj) {
        msgArea.innerHTML = `
            <p>Here's what we know of your palico:</p>
            <ul>
                <li>Palico's Name: ${editObj.palicoName}</li>
                <li>Meet Date: ${editObj.meetDate}</li>
                <li>Hunt Count: ${editObj.hunts}</li>
                <li>Helper's Strategy: ${editObj.strategy}</li>
                <li>Preference: ${editObj.preference}</li>
            </ul>
        `;
    }

    function cancel() {
        msgArea.innerHTML = `
            <p>We won't save any of your palico info.</p>
        `;
    }
    
    var editArea = MakeEditArea({
        inputSpecs: inputSpecs,
        successCallBack: success,
        cancelCallBack: cancel
    });
    palicoArea.appendChild(editArea);

    return ele;
}