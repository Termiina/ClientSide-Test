"use strict";

function SlideShow_CGF() { 

    var ele = document.createElement("div");


    ajax("json/monsters.json", extractMonsters, ele);
    function extractMonsters(monsterList) {
        var monsterSlides = monsterList.map(monster => {
            return {
                imgName: monster.image,
                caption: monster.monsterName,
                bonusInfo: monster.wyvernType
            };
        });

        var show1 = MakeSlideShow({
            title: "Wyvern Slideshow",
            slides: monsterSlides,
            imageFilter: "saturate(150%)"
        });
        ele.appendChild(show1);
    }

    ajax("json/endemic.json", extractEndemic, ele);
    function extractEndemic(endemicList) {
        var endemicSlides = endemicList.map(endemic => {
            return {
                imgName: endemic.creatureIMG,
                caption: endemic.creature,
                bonusInfo: endemic.location
            };
        });

        var show2 = MakeSlideShow({
            title: "Endemic Slideshow",
            slides: endemicSlides,
            imageFilter: "grayscale(100%)"
        });
        ele.appendChild(show2);
    }

    var dummyDiv = MakeSlideShow({});
    ele.appendChild(dummyDiv);

    return ele;
}