"use strict";

function TwoAreas_CGF(){
    
    var ele = document.createElement("div");

    ele.appendChild(MakeEditAreaWyvern_CGF());
    ele.appendChild(MakeEditAreaPalico_CGF());

    return ele;
}