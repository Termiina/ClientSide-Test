"use strict";
function MakeEntry_CGF() {
    var test = document.createElement('div');

    var entry1 = MakeEntry({ name: "Lunastra", pic: "style/Lunastra.jpg", bounty: 21000 });
    test.appendChild(entry1);

    var entry2 = MakeEntry({})
    test.appendChild(entry2);

    var entry3 = MakeEntry({ name: "Great Jagras", pic: "style/GJagras.jpg", bounty: 14000 });
    test.appendChild(entry3);

    return test;
}
