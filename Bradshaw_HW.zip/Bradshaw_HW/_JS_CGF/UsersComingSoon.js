"use strict"; //mandatory strict

function UsersComingSoon() {

    // The content that will be injected, along with the picture
    var content = `
        <div class="users-coming-soon">
            <h1>New Data is incoming!</h1>
            <p>I am working now to get more info on my Monster Hunting journey up as soon as I can!</p>

            <p>For now, here is an icon of a personal favorite monster from the game</p>
            <img class="codeImg" src="style/Zino.jpg"/> 
        </div>
    `;
    //what I want the page to say

    var ele = document.createElement("div");
    ele.innerHTML = content; // the code from earlier.


    return ele;

}